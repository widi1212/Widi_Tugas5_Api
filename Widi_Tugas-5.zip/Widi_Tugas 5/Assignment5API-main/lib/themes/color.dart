import 'package:flutter/material.dart';

const primary = Color(0xff4f359b);
const white = Color(0xffffffff);
